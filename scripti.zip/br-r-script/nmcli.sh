nmcli con
