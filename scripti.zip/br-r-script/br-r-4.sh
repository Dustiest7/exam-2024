cp backup/backup-script.sh ~/
cd --
chmod +x backup-script.sh
./backup-script.sh
#tar -tf /opt/backup/имя_архива | less
cd br-r-script


