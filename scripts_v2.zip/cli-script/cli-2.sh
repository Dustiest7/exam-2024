useradd admin -m -c "Admin" -U
passwd admin
systemctl reboot
