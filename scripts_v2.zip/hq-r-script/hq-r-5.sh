systemctl start iperf3
iperf3 -c 11.11.11.1 # нужно заменить на 11.11.11.1
iperf3 -c 11.11.11.1 --get-server-output --logfile ~/iperf3_logfile.txt
# на встречке выполняем команду iperf3 -s
