rm -rf /etc/net/ifaces/ens33/*
cp dhcp/options /etc/net/ifaces/ens33/
systemctl restart network
systemctl reboot
